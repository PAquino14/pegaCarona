//Set All Constant For Fetch Value
export const FETCH_SAMPLE_BEGIN = 'FETCH_SAMPLE_BEGIN'
